<?php
echo("
  <div id='cssmenu'>
  <ul>
     <li><a href='index.php'><span>Home</span></a></li>
     <li class='active has-sub'><a href='board.php'><span>게시판</span></a></li>
  </ul>
  </div>");
?>